# -*- coding: utf-8 -*-
##
#  @file "GetInfo.py"  
#  @brief "资讯公告预处理"
#  @brief "负责处理公告资讯，获取词频信息*词频信息获取模块*"      
#  @author "Bernard "  
#  @date "2019-5-30"  
import KeyWordSelect##"查出资讯时间，标题"  
import P2S##pdf转字符串后顺便保存txt
# Dir=u"F:\\2019sp\\Py\\源码\\参考\\PDf\\PDF2txt"
# pdfTotxt2(Dir)
# ##''
