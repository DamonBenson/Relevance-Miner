# -*- coding: utf-8 -*-
##
#  @file "InfoAnalysis.py"  
#  @brief "Matlab数据绘图"
#  @brief "对收集到的词频信息，并根据制表要求进行指定卷积等数据操作，最后生成图表"      
#  @author "Bernard "  
#  @date "2019-5-11"
import matlab.engine
def InfoAnalysis(KeyA,KeyB,Date,Requir,DictDate):