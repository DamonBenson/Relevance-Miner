# -*- coding: utf-8 -*-
##
#  @file "Show.py"  
#  @brief "展示图窗"
#  @brief "根据不同的要求负责图窗的布局"      
#  @author "Bernard "  
#  @date "2019-5-11"  
#import threading
#import InfoAnalysis
#import Tkinter as Tk
def Show(frame,UserRequir):
    #InputFrame=Tk.Frame(frame)#声明
    #InputFrame.place(relx=0.0,rely=0.0,relwidth=0.5,relheight=1)#放置
    return True
#     #print(IKEYA)
#     a=thread.start_new_thread(func,(5,))   
#     print(a)
# def func(n):
#        return n
# Show()