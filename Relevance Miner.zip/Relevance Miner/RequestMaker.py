# -*- coding: utf-8 -*-
##
#  @file "RequestMaker.py"  
#  @brief "报文发送"
#  @brief "负责发文获取pdf并存储"      
#  @author "Bernard "  
#  @date "2019-5-11"  
def RequestMaker(DateCrawl,path):
    pass