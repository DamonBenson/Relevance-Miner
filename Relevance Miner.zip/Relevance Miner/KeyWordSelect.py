# -*- coding: utf-8 -*-
##
#  @file "KeyWordSelect.py"  
#  @brief "关键信息查找"
#  @brief "查出资讯时间，标题"      
#  @author "Bernard "  
#  @date "2019-5-30" 
def KeyWordSelect(AnncString):
    return 'data','name'