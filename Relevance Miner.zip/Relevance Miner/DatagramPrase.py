# -*- coding: utf-8 -*-
##
#  @file "DatagramPrase.py"  
#  @brief "报文解析"
#  @brief "解析并识别报文中需要的公告的url"      
#  @author "Bernard "  
#  @date "2019-5-11"  
def DatagramPrase(Datagram):
    pass